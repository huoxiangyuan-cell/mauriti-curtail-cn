import json
import datetime

data = {
    "update_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
    "generation": 278.4,
    "curtailment": 79.8,
    "total_gen": 358.2,
    "curt_rate": 22.3,
    "claim_power": 14.7,
    "claim_money": "约 240 万雷亚尔",
    "months": ["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"],
    "gen_data": [22,25,29,31,33,32,28,24,26,30,32,29],
    "rate_data": [18,20,22,25,24,23,21,19,20,22,23,22],
    "reason_data": [
        {"name":"电力供给过剩","value":69.8},
        {"name":"电网可靠性约束","value":16.4},
        {"name":"外部线路受限","value":2.06},
        {"name":"未分类","value":11.7}
    ],
    "hours": ["06","07","08","09","10","11","12","13","14","15","16","17"],
    "heat_data": [[0,0,20],[1,0,35],[2,0,55],[3,0,75],[4,0,90],[5,0,95],[6,0,98],[7,0,97],[8,0,92],[9,0,70],[10,0,40],[11,0,25]],
    "claim_list": [
        {"date":"2025-12-01","value":32.4,"type":"CNF","claim":"是"},
        {"date":"2025-12-02","value":28.1,"type":"REL","claim":"是"}
    ]
}

with open("data/monthly_data.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=4)

print("✅ ONS 数据已更新完成")